'use client';

import { useState, useEffect, useCallback, useRef } from 'react';
import { EmptyState } from '@/components/ui/empty-state';
import { getProcessingJobs, deleteProcessingJob } from '@/lib/queries';
import { createClient as createSupabaseClient } from '@/lib/supabase/client';
import type { ProcessingJob } from '@/lib/types';
import { ProcessingCard } from '@/components/editing/editing-cards';
import { ReviewWorkspace } from '@/components/editing/review-workspace';
import { PhotoUpload } from '@/components/editing/photo-upload';
import {
  type ProcessingJobWithGallery,
} from '@/components/editing/mock-data';
import {
  Wand2, CheckCircle2, Eye,
  Clock, Image as ImageIcon, Loader2,
} from 'lucide-react';

type TabId = 'upload' | 'queue' | 'review';

// How long a job can be stuck with no progress before auto-failing (ms)
const STALE_TIMEOUT_MS = 5 * 60 * 1000; // 5 minutes

export default function EditingPage() {
  const [activeTab, setActiveTab] = useState<TabId>('upload');
  const [processingJobs, setProcessingJobs] = useState<ProcessingJobWithGallery[]>([]);
  const [loading, setLoading] = useState(true);
  const [reviewingJob, setReviewingJob] = useState<ProcessingJobWithGallery | null>(null);
  const pollingRef = useRef<ReturnType<typeof setInterval> | null>(null);
  // Track last known progress per job for stale detection
  const progressSnapshotRef = useRef<Map<string, { processed: number; timestamp: number }>>(new Map());

  const loadData = useCallback(async () => {
    setLoading(true);
    try {
      const pjData = await getProcessingJobs();
      setProcessingJobs(pjData as ProcessingJobWithGallery[]);
    } catch (err) {
      console.error('Error loading editing data:', err);
      setProcessingJobs([]);
    }
    setLoading(false);
  }, []);

  useEffect(() => { loadData(); }, [loadData]);

  // Cancel / dismiss a processing job
  const handleCancelJob = useCallback(async (jobId: string) => {
    // Mark as failed in DB first
    const sb = createSupabaseClient();
    await sb.from('processing_jobs').update({
      status: 'failed',
      error_log: 'Cancelled by user',
      completed_at: new Date().toISOString(),
    }).eq('id', jobId);
    // Remove from local state immediately
    setProcessingJobs((prev) => prev.filter((j) => j.id !== jobId));
  }, []);

  // Auto-dismiss failed jobs after 10 seconds
  useEffect(() => {
    const failedJobs = processingJobs.filter((j) => j.status === 'failed');
    if (failedJobs.length === 0) return;

    const timers = failedJobs.map((job) => {
      return setTimeout(async () => {
        await deleteProcessingJob(job.id);
        setProcessingJobs((prev) => prev.filter((j) => j.id !== job.id));
      }, 10000);
    });

    return () => timers.forEach(clearTimeout);
  }, [processingJobs]);

  // Poll for processing job status when on the queue tab
  const pollingActiveRef = useRef(false);

  useEffect(() => {
    if (activeTab !== 'queue') {
      if (pollingRef.current) {
        clearInterval(pollingRef.current);
        pollingRef.current = null;
        pollingActiveRef.current = false;
      }
      return;
    }

    if (pollingActiveRef.current) return;

    pollingActiveRef.current = true;
    pollingRef.current = setInterval(async () => {
      try {
        const fresh = await getProcessingJobs();
        if (fresh.length > 0) {
          // Stale job detection — if a processing job hasn't progressed in 5 min, auto-fail it
          const now = Date.now();
          for (const job of fresh) {
            if (job.status !== 'processing' && job.status !== 'queued') continue;

            const snapshot = progressSnapshotRef.current.get(job.id);
            if (snapshot) {
              if (job.processed_images > snapshot.processed) {
                // Progress made — update snapshot
                progressSnapshotRef.current.set(job.id, { processed: job.processed_images, timestamp: now });
              } else if (now - snapshot.timestamp > STALE_TIMEOUT_MS) {
                // Stale — auto-fail
                console.warn(`Processing job ${job.id} stale for 5+ min — auto-failing`);
                const sb = createSupabaseClient();
                await sb.from('processing_jobs').update({
                  status: 'failed',
                  error_log: 'Processing stalled — automatically cancelled',
                  completed_at: new Date().toISOString(),
                }).eq('id', job.id);
              }
            } else {
              // First time seeing this job — record initial snapshot
              progressSnapshotRef.current.set(job.id, { processed: job.processed_images, timestamp: now });
            }
          }

          setProcessingJobs(fresh as ProcessingJobWithGallery[]);

          const stillActive = fresh.some(
            (j: ProcessingJob) => j.status === 'processing' || j.status === 'queued'
          );
          if (!stillActive && pollingRef.current) {
            clearInterval(pollingRef.current);
            pollingRef.current = null;
            pollingActiveRef.current = false;
          }
        }
      } catch {
        // Skip this poll cycle
      }
    }, 3000);

    return () => {
      if (pollingRef.current) {
        clearInterval(pollingRef.current);
        pollingRef.current = null;
        pollingActiveRef.current = false;
      }
    };
  }, [activeTab]);

  if (loading) {
    return (
      <div className="flex items-center justify-center py-20">
        <div className="w-6 h-6 border-2 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin" />
      </div>
    );
  }

  if (reviewingJob) {
    return <ReviewWorkspace processingJob={reviewingJob} onBack={() => { setReviewingJob(null); loadData(); }} />;
  }

  const queuedCount = processingJobs.filter((j) => j.status === 'queued' || j.status === 'processing').length;
  const completedCount = processingJobs.filter((j) => j.status === 'completed').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight">Auto Editor</h1>
          <p className="text-sm text-slate-500 mt-1">AI-powered photo processing pipeline</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 border-b border-white/[0.06] -mb-px overflow-x-auto">
        {([
          { id: 'upload' as TabId, label: 'Upload Photos', count: undefined },
          { id: 'queue' as TabId, label: 'Processing Queue', count: queuedCount > 0 ? queuedCount : undefined },
          { id: 'review' as TabId, label: 'Ready for Review', count: completedCount > 0 ? completedCount : undefined },
        ]).map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`relative px-4 py-3 text-sm font-medium whitespace-nowrap transition-colors ${
              activeTab === tab.id ? 'text-white' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <span className="flex items-center gap-2">
              {tab.label}
              {tab.count !== undefined && (
                <span className={`px-1.5 py-0.5 text-[10px] rounded-full font-medium ${
                  activeTab === tab.id ? 'bg-indigo-500/20 text-indigo-400' : 'bg-white/[0.06] text-slate-500'
                }`}>{tab.count}</span>
              )}
            </span>
            {activeTab === tab.id && <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-indigo-500 rounded-full" />}
          </button>
        ))}
      </div>

      {/* Upload tab */}
      {activeTab === 'upload' && (
        <div className="max-w-2xl">
          <PhotoUpload onUploadComplete={() => loadData()} />
        </div>
      )}

      {/* Queue tab */}
      {activeTab === 'queue' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            {[
              { label: 'Processing', value: processingJobs.filter((j) => j.status === 'processing').length, icon: Loader2, color: 'indigo' },
              { label: 'Queued', value: processingJobs.filter((j) => j.status === 'queued').length, icon: Clock, color: 'slate' },
              { label: 'Completed', value: processingJobs.filter((j) => j.status === 'completed').length, icon: CheckCircle2, color: 'emerald' },
              { label: 'Total Images', value: processingJobs.reduce((sum, j) => sum + j.total_images, 0), icon: ImageIcon, color: 'violet' },
            ].map((stat) => (
              <div key={stat.label} className="rounded-xl border border-white/[0.06] bg-[#0c0c16] p-4">
                <div className="flex items-center gap-2 mb-2">
                  <div className={`w-8 h-8 rounded-lg bg-${stat.color}-500/10 flex items-center justify-center`}>
                    <stat.icon className={`w-4 h-4 text-${stat.color}-400`} />
                  </div>
                </div>
                <p className="text-xs text-slate-500">{stat.label}</p>
                <p className="text-xl font-bold text-white">{stat.value}</p>
              </div>
            ))}
          </div>

          {processingJobs.length === 0 ? (
            <EmptyState icon={Wand2} title="No processing jobs" description="Upload photos to a job and the AI processing pipeline will appear here." />
          ) : (
            <div className="space-y-3">
              {processingJobs.filter((j) => j.status === 'processing' || j.status === 'queued').map((job) => (
                <ProcessingCard key={job.id} job={job} onReview={() => setReviewingJob(job)} onCancel={() => handleCancelJob(job.id)} />
              ))}
              {processingJobs.filter((j) => j.status === 'failed').map((job) => (
                <ProcessingCard key={job.id} job={job} onReview={() => {}} onCancel={() => handleCancelJob(job.id)} />
              ))}
              {processingJobs.filter((j) => j.status === 'processing' || j.status === 'queued' || j.status === 'failed').length === 0 && (
                <div className="text-center py-8">
                  <p className="text-sm text-slate-500">No active processing jobs. All caught up!</p>
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Review tab */}
      {activeTab === 'review' && (
        <div className="space-y-3">
          {processingJobs.filter((j) => j.status === 'completed').length === 0 ? (
            <EmptyState icon={Eye} title="Nothing to review" description="Completed processing jobs will appear here for you to review and approve." />
          ) : (
            processingJobs.filter((j) => j.status === 'completed').map((job) => (
              <ProcessingCard key={job.id} job={job} onReview={() => setReviewingJob(job)} />
            ))
          )}
        </div>
      )}
    </div>
  );
}
